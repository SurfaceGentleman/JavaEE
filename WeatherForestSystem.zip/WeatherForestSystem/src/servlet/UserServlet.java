package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.buf.UDecoder;

import pojo.User;
import service.UserService;

/**
 * Servlet implementation class UserService
 */

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	
	//��ȡservice�����
	UserService us = new UserService();
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//������������ʽ
		req.setCharacterEncoding("utf-8");
		//������Ӧ�����ʽ
		resp.setContentType("text/html;charset=utf-8");
		
		String oper = req.getParameter("oper");
		if ("reg".equals(oper)) {
			System.out.println("����ע��");
			userReg(req, resp);
		}else if ("login".equals(oper)) {
			System.out.println("���õ�½");
			checkUserLogin(req, resp);
		}else if ("pwd".equals(oper)) {
			System.out.println("�����޸����룡");
			userChangePwd(req, resp);
		}else if ("all".equals(oper)) {
			System.out.println("���ò鿴");
			userAll(req,resp);
		}else if ("del".equals(oper)) {
			System.out.println("����ɾ���û�");
			userDelete(req,resp);
			
		}else if ("search".equals(oper)) {
			userSerach(req, resp);
			
		}else if ("change".equals(oper)) {
			System.out.println("�����޸�");
			userChange(req, resp);
		}else {
			System.out.println("û���ҵ���Ӧ�Ĳ�����");
		}
		
	}
	
	private void userChange(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String newName = req.getParameter("newName");
		String newPwd = req.getParameter("newPwd");
		System.out.println("���û���:" + newName + "-" + newPwd + "-" + req.getParameter("uid"));
		int uid = Integer.parseInt(req.getParameter("uid"));
		
		int index = us.userChangeService(newPwd, newName, uid);
		HttpSession hs = req.getSession();
		List<User> lu = us.userShowService();
		hs.removeAttribute("lu"); 
        hs.setAttribute("lu", lu);
		 
		//�ض�����ҳ
		resp.sendRedirect("user/userInformation.jsp");
		 
		
	}

	private void userSerach(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String uname = req.getParameter("uname");
		List<User> u_s = us.userSearchService(uname);
		//�ж�
		if (u_s != null) {
			HttpSession hs = req.getSession();
			hs.setAttribute("u_s", u_s);
					
			System.out.println(u_s);
			resp.sendRedirect("user/userInformation.jsp");
			return;
		}
	}

	private void userDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String idString = req.getParameter("uid");
		int uid = Integer.parseInt(idString);
		int index = us.userDeleteService(uid);
		HttpSession hs = req.getSession();
		List<User> lu = (List<User>)hs.getAttribute("lu");
		User delUser = null;
        for(User u : lu){
        	int temp = u.getUid();
        	if (temp == uid) {
				delUser = u;
			}
        }
        lu.remove(delUser);
        hs.removeAttribute("lu");
        hs.setAttribute("lu", lu);
		resp.sendRedirect("user/userInformation.jsp");
	}

	private void userAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//call service
		List<User> lu = us.userShowService();
		
		//�ж�
		if (lu != null) {
			HttpSession hs = req.getSession();
			hs.setAttribute("lu", lu);
			
			System.out.println(lu);
			resp.sendRedirect("user/userInformation.jsp");
			return;
		}
		
	}

	private void userChangePwd(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		String newPwd = req.getParameter("newPwd");
		User u = (User)req.getSession().getAttribute("user");
		int uid = u.getUid();
		
		int index = us.userChangePwdService(newPwd, uid);
		
		//�ض�����ҳ
		req.getRequestDispatcher("Login.jsp").forward(req, resp);
		
	}

	private void userReg(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String flString = req.getParameter("flag");
		
		String uname = req.getParameter("uname");
		System.out.println(uname);
		String pwd = req.getParameter("pwd");
		System.out.println(pwd);
		User u = new User(0, uname, pwd);
		int index = -1;
		index = us.userRegService(u);
		System.out.println(index);
		
		if (index > 0) {
			System.out.println("ע��ɹ���");
			HttpSession hs = req.getSession();
			List<User> lu = us.userShowService();
			hs.removeAttribute("lu");
		    
		    hs.setAttribute("lu", lu);
			if (flString == null) {
				
				resp.sendRedirect("Login.jsp");
			}
			else {
				resp.sendRedirect("user/userInformation.jsp");
			}
		}
		
	}

	public void checkUserLogin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uname = req.getParameter("uname");
		String pwd = req.getParameter("pwd");
		System.out.println(uname + ":" + pwd);
		//����������Ϣ
			
			//У��
			User u = us.checkUserLoginService(uname, pwd);
			
			if (u != null) {
				HttpSession hs = req.getSession();
				hs.setAttribute("user", u);
				
				//�ض�����ҳ
				req.getRequestDispatcher("skip/skip_weather.jsp").forward(req, resp);
				
			}else { 
				
				req.setAttribute("flag", 0);
				req.getRequestDispatcher("Login.jsp").forward(req, resp);
			}
	}
	                                        
}
