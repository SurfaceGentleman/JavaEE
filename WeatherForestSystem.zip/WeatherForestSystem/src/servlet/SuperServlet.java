package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojo.SuperUser;
import service.SuperService;

/**
 * Servlet implementation class SuperServlet
 */
@WebServlet("/SuperServlet")
public class SuperServlet extends HttpServlet {
	
	SuperService sp = new SuperService();
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//������������ʽ
				req.setCharacterEncoding("utf-8");
				//������Ӧ�����ʽ
				resp.setContentType("text/html;charset=utf-8");
				//��ȡ������
				String operString = req.getParameter("oper");
				
				if ("Login".equals(operString)) {
					//���õ�½��������
					checkSuperUserLogin(req, resp);
				}
				
	}
	private void checkSuperUserLogin(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		String uname = req.getParameter("uname");
		String pwd = req.getParameter("pwd");
		System.out.println("��������Ա����" + uname + ":" + pwd);
		
		SuperUser su = sp.checkSuperUserLoginService(uname, pwd);
		
		if (su != null) {
			//��ȡsession����
			HttpSession hs = req.getSession();
			//���û����ݴ洢��session��
			hs.setAttribute("super", su);
			//�ض���
			resp.sendRedirect("skip/skip_super.jsp");
		}
		else {
			req.getRequestDispatcher("user/super_login.jsp").forward(req, resp);
			return;
		}
	}
}
