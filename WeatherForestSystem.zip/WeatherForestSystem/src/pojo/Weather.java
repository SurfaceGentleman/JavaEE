package pojo;

import java.util.ArrayList;
import java.util.List;

import dao.Query;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


public class Weather {
	public class Daily{
		public String date;
		public String week;
		public String weather;
		public String img;
		public Daily(String date, String week, String weather, String img) {
			super();
			this.date = date;
			this.week = week;
			this.weather = weather;
			this.img = img;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getWeek() {
			return week;
		}
		public void setWeek(String week) {
			this.week = week;
		}
		public String getWeather() {
			return weather;
		}
		public void setWeather(String weather) {
			this.weather = weather;
		}
		public String getImg() {
			return img;
		}
		public void setImg(String img) {
			this.img = img;
		}
		

	}

	public class Hourly{
		public Hourly(String time, String weather, String temp, String img) {
			super();
			this.time = time;
			this.weather = weather;
			this.temp = temp;
			this.img = img;
		}
		public String time;
		public String weather;
		public String temp;
		public String img;
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}
		public String getWeather() {
			return weather;
		}
		public void setWeather(String weather) {
			this.weather = weather;
		}
		public String getTemp() {
			return temp;
		}
		public void setTemp(String temp) {
			this.temp = temp;
		}
		public String getImg() {
			return img;
		}
		public void setImg(String img) {
			this.img = img;
		}
		
	}
	
	public JSONObject json = null;
	JSONObject resultarr = null;
	public Weather(String city) throws Exception {
		json = Query.Get(city);
		while(true) {
			if (json == null) {
				System.out.println("����������");
				continue;
			}else {
				break;
			}
		}
		resultarr = json.optJSONObject("result");
		
	}
	
	public String getPm2_5() {
		JSONObject aqi = resultarr.optJSONObject("aqi");
		String pm2_5 = aqi.getString("pm2_5");
		return pm2_5;
	}
	
	public String getAir() {
		JSONArray index = resultarr.optJSONArray("index");
		JSONObject obj = (JSONObject) index.opt(0);
		String ivalue = obj.getString("ivalue");
		return ivalue;
	}
	
	public String getExercise() {
		JSONArray index = resultarr.optJSONArray("index");
		JSONObject obj = (JSONObject) index.opt(1);
		String ivalue = obj.getString("ivalue");
		return ivalue;
	}
	
	public String getTempHigh() {
		
		String temphigh = resultarr.getString("temphigh");
		return temphigh;
	}
	
	public String getTempLow() {
		String templow = resultarr.getString("templow");
		return templow;
	}
	
	public String getQuality() {
		JSONObject aqi = resultarr.optJSONObject("aqi");
		String quality = aqi.getString("quality");
		return quality;
	}
	
	public String getCity() {
        String city = resultarr.getString("city");
		return city;
	}
    
	public String getTemp() {
		String temp = resultarr.getString("temp");
		return temp;
	}
	
	public String getWeather() {
		return resultarr.getString("weather");
	}
	
	public List<Daily> getDaily() {
		JSONArray dailyJson = resultarr.optJSONArray("daily");
		List<Daily> dailylList = new ArrayList<Daily>();
		for(int i = 0; i < dailyJson.length(); i++) {
			JSONObject obj = (JSONObject) dailyJson.opt(i);
			String date = obj.getString("date");
			String week = obj.getString("week");
			JSONObject day = obj.optJSONObject("day");
			String weather = day.getString("weather");
			String img = day.getString("img");
			Daily d = new Daily(date, week, weather, img);
			dailylList.add(d);
		}
		return dailylList;
	}
	
	public List<Hourly> getHourly(){
		List<Hourly> hourlyList = new ArrayList<Hourly>();
		JSONArray hourlyJson = resultarr.optJSONArray("hourly");
		for (int i = 0; i < hourlyJson.length(); i++) {
			JSONObject obj = (JSONObject) hourlyJson.opt(i);
            String time = obj.getString("time");
            String weather = obj.getString("weather");
            String temp = obj.getString("temp");
            String img = obj.getString("img");
            Hourly h = new Hourly(time, weather, temp, img);
            hourlyList.add(h);
		}
		return hourlyList;
	}
	
	public static void main(String[] args) throws Exception {
		Weather w = new Weather("����");
		System.out.println(w.getCity());
		System.out.println(w.getTemp());
		System.out.println(w.getDaily());
		System.out.println(w.getHourly());
	}
	
}



