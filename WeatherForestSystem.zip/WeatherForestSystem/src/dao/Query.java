package dao;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;



import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import pojo.HttpUtil;

public class Query {

    public static final String APPKEY = "42a1b7d9c0d97c88";// �ҵ�appkey
    public static final String URL = "https://api.jisuapi.com/weather/query";
    //public static final String city = "����";// utf-8
    public static final int cityid = 111;// ��ѡ
    public static final String citycode = "101260301";// ��ѡ
    
    public static JSONObject Get(String city) throws Exception  {
        String result = null;
        String url = URL + "?appkey=" + APPKEY + "&city="
        + URLEncoder.encode(city, "utf-8");

        try {
            result = HttpUtil.sendGet(url, "utf-8");
            JSONObject json = JSONObject.fromObject(result);
            if (json.getInt("status") != 0) {
                System.out.println(json.getString("msg"));
            } else {
            	
                return json;
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		return null;
    }
    public static void main(String[] args) throws Exception {
		JSONObject jsonObject =  Query.Get("����");
		System.out.println(jsonObject);
	}
}

