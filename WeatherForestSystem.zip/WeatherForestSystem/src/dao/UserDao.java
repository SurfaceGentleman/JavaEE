package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import pojo.User;

public class UserDao {
	public User checkUserLoginDao(String name, String pwd) {
		//����jdbc����
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//��������
		User u = null;
		try {
			//��������
			Class.forName("com.mysql.cj.jdbc.Driver");
			//��ȡ����
			final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
			conn = DriverManager.getConnection(URL, "root", "1226568176");
			//����sql����
			String sql = "select * from u_infor where uname=? and pwd=?";
			//����sql�������
			ps = conn.prepareStatement(sql);
			//��ռλ����ֵ
			ps.setString(1, name);
			ps.setString(2, pwd);
			//ִ��sql
			rs =  ps.executeQuery();
			//�������
			while (rs.next()) {
				//��������ֵ
				u = new User();
				u.setUid(rs.getInt("uid"));
				u.setUname(rs.getString("uname"));
				u.setPwd(rs.getString("pwd"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//�ر���Դ
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//���ؽ��
		
		return u;
	}

	public int userRegDao(User u) {
		//����jdbc����
		Connection conn = null;
		PreparedStatement ps = null;
		int index = -1;
		
		try {
			//��������
			Class.forName("com.mysql.cj.jdbc.Driver");
			//��ȡ����
			final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
			conn = DriverManager.getConnection(URL, "root", "1226568176");
			//����sql����
			String sql = "insert into u_infor values(default, ?, ?)";
			//����sql�������
			ps = conn.prepareStatement(sql);
			//��ռλ����ֵ
			ps.setString(1, u.getUname());
			ps.setString(2, u.getPwd());
			//ִ��sql
			index =  ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//�ر���Դ
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return index;
	}

	public int userChangePwdDao(String newPwd, int uid){
		//change passsword through ID
		//����jdbc����
		Connection conn = null;
		PreparedStatement ps = null;
		int index = -1;
		//��������
		System.out.println(newPwd);
		try {
			//��������
			Class.forName("com.mysql.cj.jdbc.Driver");
			//��ȡ����
			final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
			conn = DriverManager.getConnection(URL, "root", "1226568176");
			
			//����sql����
			String sql = "update u_infor set pwd=? where uid=?";
			//����sql�������
			ps = conn.prepareStatement(sql);
			ps.setString(1, newPwd);
			ps.setInt(2, uid);
			//ִ��sql
			index =  ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//�ر���Դ
			
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		//���ؽ��
		
		return index;
	}

	public List<User> userShowDao() {
		//����jdbc����
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
				
		//��������
		List<User> lu = null;
		try {
			//��������
			Class.forName("com.mysql.cj.jdbc.Driver");
			//��ȡ����
			final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
			conn = DriverManager.getConnection(URL, "root", "1226568176");
			
			//����sql����
			String sql = "select * from u_infor";
			ps = conn.prepareStatement(sql);					
			//ִ��sql
			rs = ps.executeQuery();
			// init set
			lu = new ArrayList<User>();
			//�������
			while (rs.next()) {
				//��������ֵ
				User u = new User();
				u.setUid(rs.getInt("uid"));
				u.setUname(rs.getString("uname"));
				u.setPwd(rs.getString("pwd"));
				lu.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//�ر���Դ
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return lu;
	}

	public int userDeleteDao(int uid) {
		int index = -1;
		//����jdbc����
				Connection conn = null;
				PreparedStatement ps = null;
				
				//��������
				User u = null;
				
				try {
					//��������
					Class.forName("com.mysql.cj.jdbc.Driver");
					//��ȡ����
					final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
					conn = DriverManager.getConnection(URL, "root", "1226568176");
					
					//����sql����
					String sql = "delete from u_infor where uid=?";
					//����sql�������
					ps = conn.prepareStatement(sql);
					ps.setInt(1, uid);
					//ִ��sql
					index =  ps.executeUpdate();
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally {
					//�ر���Դ
					
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
				//���ؽ��
				
		return index;
	}

	public List<User> userSearch(String uname) {
		List<User> u_s = null;
		//����jdbc����
				Connection conn = null;
				PreparedStatement ps = null;
				ResultSet rs = null;
				try {
					//��������
					Class.forName("com.mysql.cj.jdbc.Driver");
					//��ȡ����
					final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
					conn = DriverManager.getConnection(URL, "root", "1226568176");
					
					//����sql����
					String sql = "select * from u_infor where uname=?";
					ps = conn.prepareStatement(sql);
					ps.setString(1, uname);
					//ִ��sql
					rs = ps.executeQuery();
					// init set
					u_s = new ArrayList<User>();
					//�������
					while (rs.next()) {
						//��������ֵ
						User u = new User();
						u.setUid(rs.getInt("uid"));
						u.setUname(rs.getString("uname"));
						u.setPwd(rs.getString("pwd"));
						u_s.add(u);
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally {
					//�ر���Դ
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}	
		
		return u_s;
	}

	public int userChangeDao(String newPwd, String newName, int uid) {
		int index = -1;
		//����jdbc����
				Connection conn = null;
				PreparedStatement ps = null;
				
				//��������
				User u = null;
				System.out.println(newPwd);
				try {
					//��������
					Class.forName("com.mysql.cj.jdbc.Driver");
					//��ȡ����
					final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
					conn = DriverManager.getConnection(URL, "root", "1226568176");
					
					//����sql����
					String sql = "update u_infor set pwd=? , uname=? where uid=?";
					//����sql�������
					ps = conn.prepareStatement(sql);
					ps.setString(1, newPwd);
					ps.setString(2, newName);
					ps.setInt(3, uid);
					//ִ��sql
					index =  ps.executeUpdate();
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally {
					//�ر���Դ
					
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
		return index;
	}
}
