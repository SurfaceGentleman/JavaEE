package dao;

import java.sql.*;

import pojo.SuperUser;

public class SuperDao {

	public SuperUser checkSuperLoginDao(String uname, String pwd) {
		//����jdbc����
				Connection conn = null;
				PreparedStatement ps = null;
				ResultSet rs = null;
				//��������
				SuperUser sp = null;
				
				try {
					//��������
					Class.forName("com.mysql.cj.jdbc.Driver");
					//��ȡ����
					final String URL="jdbc:mysql://localhost:3306/weather?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
					conn = DriverManager.getConnection(URL, "root", "1226568176");
					
					//����sql����
					String sql = "select * from super_user where uname=? and pwd=?";
					//����sql�������
					ps = conn.prepareStatement(sql);
					//��ռλ����ֵ
					ps.setString(1, uname);
					ps.setString(2, pwd);
					//ִ��sql
					rs =  ps.executeQuery();
					//�������
					while (rs.next()) {
						//��������ֵ
						sp = new SuperUser();
						
						sp.setUname(rs.getString("uname"));
						sp.setPwd(rs.getString("pwd"));
						
					}
				} catch (Exception e) {
					e.printStackTrace();
				}finally {
					//�ر���Դ
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					
				
				
		return sp;
	}

}
