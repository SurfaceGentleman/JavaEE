package service;

import java.sql.SQLException;
import java.util.List;

import org.apache.tomcat.util.buf.UDecoder;

import dao.UserDao;
import pojo.User;

public class UserService {
	UserDao ud = new UserDao();
	public User checkUserLoginService(String uname, String pwd) {
		
		
		
		//��ӡ��־
		
		User u = ud.checkUserLoginDao(uname, pwd);
		//�ж�
		if(u != null) {
			System.out.println(uname + "�ѵ�¼�ɹ�!");
		}else {
			System.out.println("��½ʧ��!");
		}
		
		return u;
		
		
	}
	public int userRegService(User u) {
		
		return ud.userRegDao(u);
	}
	public int userChangePwdService(String newPwd, int uid){
		int index = -1;
		index = ud.userChangePwdDao(newPwd, uid);
		return index;
	}
	public List<User> userShowService() {
		List<User> lu = ud.userShowDao();
		
		return lu;
	}
	public int userDeleteService(int uid) {
		int index = -1;
		index = ud.userDeleteDao(uid);
		return index;
	}
	public List<User> userSearchService(String uname) {
		List<User> u_s = ud.userSearch(uname);
		
		return u_s;
	}
	public int userChangeService(String newPwd, String newName, int uid) {
		int index = -1;
		index = ud.userChangeDao(newPwd, newName, uid);
		
		
		return index;
	}


}
