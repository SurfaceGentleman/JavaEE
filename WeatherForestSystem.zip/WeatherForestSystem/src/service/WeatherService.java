package service;

import pojo.Weather;

public class WeatherService {

	public Weather searchService(String city) throws Exception {
		Weather w = new Weather(city);
		return w;
	}
	
	
}
