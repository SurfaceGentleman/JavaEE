package service;

import dao.SuperDao;
import pojo.SuperUser;

public class SuperService {
	SuperDao sDao = new SuperDao();
	public SuperUser checkSuperUserLoginService(String uname, String pwd) {
		
		SuperUser sp = sDao.checkSuperLoginDao(uname, pwd);
		
		//�ж�
		if(sp != null) {
			System.out.println(uname + "��½�ɹ�");
		}else {
			System.out.println("��½ʧ��");
		}
		return sp;
	
	}
	
}
